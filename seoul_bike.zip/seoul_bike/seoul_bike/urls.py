"""seoul_bike URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path("admin/", admin.site.urls),
    path('', views.index, name='index'),
    path('time1/', views.time1, name='time1'),
    path('time21/', views.time21, name='time21'),
    path('time22/', views.time22, name='time22'),
    path('time23/', views.time23, name='time23'),
    path('facilities1/', views.facilities1, name='facilities1'),
    path('facilities2/', views.facilities2, name='facilities2'),
    path('facilities3/', views.facilities3, name='facilities3'),
]
